"""
Secure vulnerability scanner (sandbox version)
Author: Freddy
"""
import subprocess, json

def scan_host(target: str):
    try:
        result = subprocess.run(["nmap","-F",target],capture_output=True,text=True,timeout=30,check=True)
        return {"target":target,"status":"completed","output":result.stdout}
    except Exception as e:
        return {"target":target,"status":"error","details":str(e)}

if __name__ == "__main__":
    print(json.dumps(scan_host("127.0.0.1"), indent=2))
