"""
Log parser
Author: Freddy
"""
import re
def parse_auth_log(lines):
    pattern = re.compile(r"Failed password for (\w+)")
    results = {}
    for line in lines:
        m = pattern.search(line)
        if m:
            results[m.group(1)] = results.get(m.group(1),0)+1
    return results
