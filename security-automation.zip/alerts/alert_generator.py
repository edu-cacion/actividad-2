"""
Alert generator
Author: Freddy
"""
import json
from datetime import datetime
def generate_alert(source,severity,description):
    return json.dumps({
        "timestamp":datetime.utcnow().isoformat(),
        "source":source,
        "severity":severity,
        "description":description
    }, indent=2)
